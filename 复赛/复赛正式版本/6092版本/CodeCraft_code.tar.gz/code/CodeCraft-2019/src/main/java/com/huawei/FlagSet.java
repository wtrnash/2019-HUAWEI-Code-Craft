package com.huawei;
public class FlagSet {
    public static int NOT_FIND=-1;
    public static int FRONT_WAIT=-3;
    public static int ALL_STOP=-2;
}
